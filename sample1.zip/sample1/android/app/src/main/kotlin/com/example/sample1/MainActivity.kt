package com.example.sample1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
