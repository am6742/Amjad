import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          "My portfolio",
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 20,
            color: Colors.black,
          ),
        ),
      ),
      body: Center(
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text("Hi I am Amjad",
                      style:
                          TextStyle(fontSize: 30, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 20),
                  Text("Full Stack Developer in Cognizant",
                      style: TextStyle(fontSize: 25, color: Colors.grey)),
                  const SizedBox(height: 20),
                  TextButton(
                    onPressed: () {
                      print("Hello Amjad");
                      Navigator.pushNamed(context, '/about');
                    },
                    child: Text("About me",
                        style: TextStyle(
                            color: Colors.black,
                            fontSize: 15,
                            fontWeight: FontWeight.bold)),
                    style: ButtonStyle(
                        backgroundColor:
                            MaterialStateProperty.all(Colors.amber)),
                  )
                ]),
            const SizedBox(width: 40),
            Hero(
              tag: 'Amjad.JPG',
              child: Container(
                height: 300,
                width: 300,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  image:
                      DecorationImage(image: AssetImage("assets/Amjad.JPG")),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.amber,
                      offset: Offset(0, 0),
                      blurRadius: 5,
                      spreadRadius: 12,
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
      floatingActionButton: Container(
          height: 50,
          width: 300,
          decoration: BoxDecoration(
            color: Colors.amber,
            borderRadius: BorderRadius.circular(30),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.5),
                offset: Offset(0, 0),
                blurRadius: 5,
                spreadRadius: 7,
              ),
            ],

          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
            InkWell(
              onTap: () async {
                await launchUrl(Uri.parse("https://github.com/am6742/Amjad"));
              },
              child:
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Image.asset('assets/Copy of github.png'),
                ),
            ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Image.asset('assets/Copy of email.png'),
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Image.asset('assets/Copy of linkedin.png'),
                ),
                Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Image.asset('assets/Copy of instagram.png'),
                ),
            ],
            ),
          ),
    );
  }
}
