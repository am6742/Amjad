import 'package:flutter/material.dart';

class about extends StatelessWidget {
  const about({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child:Row(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              height: 300,
              width: 300,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                image:
                DecorationImage(image: AssetImage("assets/Amjad.JPG")),
                boxShadow: [
                  BoxShadow(
                    color: Colors.amber,
                    offset: Offset(0, 0),
                    blurRadius: 5,
                    spreadRadius: 12,
                  ),
                ],
              ),
            ),
            const SizedBox(width:50,),
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  "Developer\nResearcher\nCoding Fever",
                  style: TextStyle(
                    fontSize:35,
                    fontWeight: FontWeight.bold,
                    color: Colors.black,
                  )
                ),
                const SizedBox(height: 20,),
                Text("""
                Hi This is AMJADSHA,
                SPEED ONE TERAHERTZ MEMORY 1 KB
                """,
                  textAlign: TextAlign.right,
                  style:TextStyle(
                     fontSize: 20,
                     color: Colors.grey,
                   ),
                )
              ],
            )

          ],
        )
      )
    );
  }
}
